﻿GM.Name = "SZ"
GM.Author = "NickSam3"
GM.Email = "N/A"
GM.Website = "N/A"

function 
GM:Initialize()
print("Игровой режим полностью запущен! By NickSam3")
end